import { Route, Routes } from "react-router-dom";
import Layout from "./app/components/ui/layout";
import NotFound from "./app/components/ui/notFound";
import Main from "./app/pages/mainPage";
import User from "./app/pages/userPage";
import Favourites from "./app/pages/favourites";

const App = () => {
    <>
        asd
        <Routes>
            <Route element={<Layout />}>
                <Route index element={<Main />} />
                <Route path="user/:userId" element={<User />} />
                <Route path="favourites" element={<Favourites />} />
                <Route path="*" element={<NotFound />} />
            </Route>
        </Routes>
        ;
    </>;
};

export default App;
