const Member = (user) => {
    console.log(user);
    return <h2>Member</h2>;
};

export default Member;
