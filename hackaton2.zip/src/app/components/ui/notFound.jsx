const NotFound = () => {
    return <h1>NotFound Page 404 </h1>;
};

export default NotFound;
