const Breadcrumbs = () => {
    return <div>Breadcrumbs</div>;
};

export default Breadcrumbs;
