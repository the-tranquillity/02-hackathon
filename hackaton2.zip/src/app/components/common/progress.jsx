const Progress = () => {
    return <div>Progress</div>;
};

export default Progress;
