const Badge = () => {
    return <div>Badge</div>;
};

export default Badge;
