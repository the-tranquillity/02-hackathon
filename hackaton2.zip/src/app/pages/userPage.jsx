const User = () => {
    return <div>User</div>;
};

export default User;
