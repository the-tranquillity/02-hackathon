const Favourites = () => {
  return <div>favourites</div>;
};

export default Favourites;
